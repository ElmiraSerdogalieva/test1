package New;

/**
 * Created by апаив on 31.10.2016.
 */
abstract public class Unit {
    int currentHp;
    //int hitPointsMax;
    public abstract void create();
}

