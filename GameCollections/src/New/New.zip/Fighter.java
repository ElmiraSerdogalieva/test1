package New;

/**
 * Created by апаив on 31.10.2016.
 */
public interface Fighter {
    public void fight(Unit unit);
}
